--[[
	Init script
]]--

Console.log("Loading resource group: 'fs://data/core.zip'")

Resources.loadPackage('fs://data/core.zip')
Resources.unloadGroup('tmp')