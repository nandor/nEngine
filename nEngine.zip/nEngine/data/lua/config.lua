--[[
    Configuration for nEngine
]]--

fullScreen = false
displayWidth = 1024
displayHeight = 768
maxFPS = 40